# AirPass Nearby — Single Render Web Service

This package serves the frontend and Node.js/WebSocket signaling backend from the same Render service and URL.

## Deploy
1. Upload this folder to a GitHub repository (files at the repository root; `public/` is a subfolder).
2. In Render, choose **New + → Web Service** and connect that repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. Deploy. Open the Render URL and check `/api/health` returns JSON with `ok: true`.
5. Open the same URL in two separate browsers/devices, enable discovery and test pairing/transfer.

## Notes
- `public/config.js` deliberately uses an empty server URL so the browser connects to the same origin. Do not change it for a single-service deployment.
- The app uses WebSocket signaling and WebRTC for direct file transfer. Some restrictive networks may need a TURN server configured via `ICE_SERVERS_JSON` on Render.
- Presence and history are in memory in this version; restarting/redeploying the service clears server-side in-memory history and online device sessions.
- The service has not been live-tested on Render or between two physical devices. Verify `/api/health`, browser console, and the two-device flow after deployment.
